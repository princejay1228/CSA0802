"""
Report Generator service for the Smart Waste Management System.
Aggregates live client, scheduling, and billing data to produce a dynamic summary report.
"""
import os
import logging
from datetime import datetime
from typing import Dict, Any, List
from managers.client_manager import ClientManager
from managers.schedule_manager import ScheduleManager
from services.billing import BillingService
from models.household import HouseholdClient
from models.industrial import IndustrialClient
from models.hospital import HospitalClient

logger = logging.getLogger("SmartWasteManager")


class ReportGenerator:
    """
    Generates dynamic analytical summary reports based on persisted data.
    """

    def __init__(
        self,
        client_manager: ClientManager,
        schedule_manager: ScheduleManager,
        billing_service: BillingService,
        reports_dir: str = "reports"
    ) -> None:
        self.client_manager = client_manager
        self.schedule_manager = schedule_manager
        self.billing_service = billing_service
        self.reports_dir = reports_dir
        os.makedirs(self.reports_dir, exist_ok=True)

    def generate_summary_report(self, file_name: str = "summary_report.txt") -> str:
        """
        Calculates all real statistics from stored clients, schedules, and billing rates,
        and saves a formatted summary report to text file.
        Returns the path to the report file.
        """
        clients = self.client_manager.get_all_clients()
        schedules = self.schedule_manager.get_all_schedules()

        total_clients = len(clients)
        household_clients = [c for c in clients if isinstance(c, HouseholdClient)]
        industrial_clients = [c for c in clients if isinstance(c, IndustrialClient)]
        hospital_clients = [c for c in clients if isinstance(c, HospitalClient)]

        total_waste_kg = sum(c.waste_quantity for c in clients)
        total_projected_revenue = sum(
            self.billing_service.calculate_bill_for_client(c) for c in clients
        )

        # Schedule statistics
        completed_collections = [s for s in schedules if s.get("status") == "Completed"]
        pending_collections = [
            s for s in schedules if s.get("status") in ["Scheduled", "In-Progress", "Pending"]
        ]
        cancelled_collections = [s for s in schedules if s.get("status") == "Cancelled"]

        # Hospital compliance statistics
        compliant_hospitals = [
            h for h in hospital_clients if h.compliance_status == "Compliant"
        ]
        pending_hospitals = [
            h for h in hospital_clients if h.compliance_status == "Pending Verification"
        ]
        non_compliant_hospitals = [
            h for h in hospital_clients if h.compliance_status == "Non-Compliant"
        ]

        report_path = os.path.join(self.reports_dir, file_name)
        timestamp_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        report_lines = [
            "==================================================================",
            "             SMART WASTE MANAGEMENT SYSTEM - SUMMARY REPORT",
            "==================================================================",
            f"Generated On           : {timestamp_str}",
            f"Active Reporting Node  : Municipal Waste Operations Control Center",
            "------------------------------------------------------------------",
            "1. CLIENT DEMOGRAPHICS & REGISTRATION",
            f"   Total Registered Clients    : {total_clients}",
            f"   - Household Clients         : {len(household_clients)}",
            f"   - Industrial Clients        : {len(industrial_clients)}",
            f"   - Hospital/Medical Clients  : {len(hospital_clients)}",
            "",
            "2. WASTE VOLUME & FINANCIAL SUMMARY",
            f"   Total Waste Volume Tracked  : {total_waste_kg:.2f} kg",
            f"   Total Projected/Billed Rev  : ${total_projected_revenue:.2f}",
            "",
            "3. COLLECTION OPERATIONS & SCHEDULE PERFORMANCE",
            f"   Total Schedules Logged      : {len(schedules)}",
            f"   - Completed Pickups         : {len(completed_collections)}",
            f"   - Pending/Scheduled Pickups : {len(pending_collections)}",
            f"   - Cancelled Pickups         : {len(cancelled_collections)}",
            "",
            "4. BIOMEDICAL WASTE COMPLIANCE TRACKING (HOSPITALS)",
            f"   Total Hospitals Registered  : {len(hospital_clients)}",
            f"   - Compliant Facilities      : {len(compliant_hospitals)}",
            f"   - Pending Verification      : {len(pending_hospitals)}",
            f"   - Non-Compliant Facilities  : {len(non_compliant_hospitals)}",
        ]

        if pending_hospitals or non_compliant_hospitals:
            report_lines.append("")
            report_lines.append("   [!] ACTION REQUIRED FOR REGULATORY AUDITING:")
            for h in non_compliant_hospitals:
                report_lines.append(
                    f"       * NON-COMPLIANT: ID={h.client_id}, Name={h.name}, "
                    f"Category={h.biomedical_category}, License={h.license_number}"
                )
            for h in pending_hospitals:
                report_lines.append(
                    f"       * PENDING VERIFY: ID={h.client_id}, Name={h.name}, "
                    f"Category={h.biomedical_category}, Requirements={h.disposal_requirements}"
                )
        else:
            report_lines.append("")
            report_lines.append("   All registered hospital facilities meet biomedical disposal standards.")

        report_lines.extend([
            "",
            "5. SCHEDULE MANIFEST LISTING",
            "   " + "-" * 60,
            f"   {'Schedule ID':<12} {'Client ID':<10} {'Date':<12} {'Time':<8} {'Status':<12}",
            "   " + "-" * 60,
        ])

        if schedules:
            for s in schedules:
                report_lines.append(
                    f"   {s.get('schedule_id', 'N/A'):<12} "
                    f"{s.get('client_id', 'N/A'):<10} "
                    f"{s.get('collection_date', 'N/A'):<12} "
                    f"{s.get('collection_time', 'N/A'):<8} "
                    f"{s.get('status', 'N/A'):<12}"
                )
        else:
            report_lines.append("   No collection schedules currently registered.")

        report_lines.extend([
            "   " + "-" * 60,
            "==================================================================",
            "                   END OF SUMMARY REPORT",
            "==================================================================",
        ])

        report_content = "\n".join(report_lines) + "\n"

        try:
            with open(report_path, "w", encoding="utf-8") as f:
                f.write(report_content)
            logger.info(f"Summary report generated successfully at: {report_path}")
            return report_path
        except Exception as e:
            logger.error(f"Failed to generate summary report at {report_path}: {e}")
            raise IOError(f"Could not generate report file: {e}")
