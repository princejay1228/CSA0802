"""
Billing Service for the Smart Waste Management System.
Handles CSV rate loading, bill computation, and receipt text file generation.
"""
import os
import csv
import logging
from datetime import datetime
from typing import Dict, Tuple, Optional, Any
from models.waste_client import WasteClient
from models.hospital import HospitalClient
from models.household import HouseholdClient
from models.industrial import IndustrialClient

logger = logging.getLogger("SmartWasteManager")


class BillingService:
    """
    Service responsible for loading rates from CSV, calculating charges, and issuing receipts.
    """

    def __init__(
        self,
        rates_csv_path: str = "data/rates.csv",
        receipts_dir: str = "receipts"
    ) -> None:
        self.rates_csv_path = rates_csv_path
        self.receipts_dir = receipts_dir
        self._ensure_paths()
        self.rate_table: Dict[Tuple[str, str], float] = self.load_rates_from_csv()

    def _ensure_paths(self) -> None:
        """
        Ensures the rates CSV file and receipts directory exist.
        """
        os.makedirs(self.receipts_dir, exist_ok=True)
        csv_dir = os.path.dirname(self.rates_csv_path)
        if csv_dir and not os.path.exists(csv_dir):
            os.makedirs(csv_dir, exist_ok=True)

        if not os.path.exists(self.rates_csv_path):
            self._create_default_rates_csv()

    def _create_default_rates_csv(self) -> None:
        """
        Initializes a default rates.csv file if none is present.
        """
        default_rates = [
            ["client_type", "waste_type", "rate_per_kg"],
            ["Household", "General", "5.0"],
            ["Household", "Recyclable", "3.0"],
            ["Household", "Organic", "4.0"],
            ["Industrial", "General", "10.0"],
            ["Industrial", "Hazardous", "25.0"],
            ["Industrial", "Chemical", "35.0"],
            ["Industrial", "Toxic", "45.0"],
            ["Hospital", "Biomedical", "40.0"],
            ["Hospital", "General", "15.0"],
            ["Hospital", "Sharps", "45.0"],
            ["Hospital", "Pathological", "50.0"],
        ]
        try:
            with open(self.rates_csv_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerows(default_rates)
            logger.info(f"Created default rates CSV at: {self.rates_csv_path}")
        except Exception as e:
            logger.error(f"Failed to create default rates CSV: {e}")

    def load_rates_from_csv(self) -> Dict[Tuple[str, str], float]:
        """
        Reads billing rates from CSV file using Python's built-in csv module.
        Returns a dictionary mapping (client_type.lower(), waste_type.lower()) -> rate_per_kg.
        """
        rates: Dict[Tuple[str, str], float] = {}
        if not os.path.exists(self.rates_csv_path):
            self._create_default_rates_csv()

        try:
            with open(self.rates_csv_path, "r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                for row_num, row in enumerate(reader, start=2):
                    try:
                        c_type = row["client_type"].strip().lower()
                        w_type = row["waste_type"].strip().lower()
                        rate_val = float(row["rate_per_kg"].strip())
                        rates[(c_type, w_type)] = rate_val
                    except (KeyError, ValueError) as err:
                        logger.warning(
                            f"Invalid or corrupted row #{row_num} in {self.rates_csv_path}: {row} ({err})"
                        )
            logger.info(f"Loaded {len(rates)} rate entries from CSV: {self.rates_csv_path}")
        except Exception as e:
            logger.error(f"Error loading rates from CSV {self.rates_csv_path}: {e}")
            # Fallback hardcoded defaults in case of file error
            rates = {
                ("household", "general"): 5.0,
                ("industrial", "general"): 10.0,
                ("industrial", "hazardous"): 25.0,
                ("hospital", "biomedical"): 40.0,
                ("hospital", "general"): 15.0,
            }
        return rates

    def get_rate_per_kg(self, client_type: str, waste_type: str) -> float:
        """
        Retrieves rate per kg for a specific client type and waste type.
        """
        key = (client_type.strip().lower(), waste_type.strip().lower())
        if key in self.rate_table:
            return self.rate_table[key]
        # Fallback to general rate
        general_key = (client_type.strip().lower(), "general")
        return self.rate_table.get(general_key, 10.0)

    def calculate_bill_for_client(self, client: WasteClient) -> float:
        """
        Calculates total bill for a given client model.
        Logs the calculation event.
        """
        # Reload rates in case CSV was modified externally
        self.rate_table = self.load_rates_from_csv()
        total_amount = client.calculate_bill(self.rate_table)
        logger.info(
            f"Bill calculated for Client {client.client_id} ({client.name}): "
            f"Qty={client.waste_quantity}kg, Type={client.waste_type}, Total=${total_amount:.2f}"
        )
        return total_amount

    def generate_receipt(
        self,
        client: WasteClient,
        collection_date: Optional[str] = None,
        collection_time: Optional[str] = None
    ) -> str:
        """
        Generates a formatted text receipt file in receipts/ folder.
        Returns the absolute/relative file path to the generated receipt.
        """
        now = datetime.now()
        date_str = collection_date or now.strftime("%Y-%m-%d")
        time_str = collection_time or now.strftime("%H:%M")
        
        # Calculate bill
        total_bill = self.calculate_bill_for_client(client)
        unit_rate = self.get_rate_per_kg(client.client_type, client.waste_type)
        base_charge = client.waste_quantity * unit_rate

        receipt_filename = f"{client.client_id}_receipt.txt"
        receipt_path = os.path.join(self.receipts_dir, receipt_filename)

        lines = [
            "=" * 50,
            "       SMART WASTE MANAGEMENT SYSTEM",
            "          OFFICIAL PAYMENT RECEIPT",
            "=" * 50,
            f"Receipt Date     : {now.strftime('%Y-%m-%d %H:%M:%S')}",
            f"Client ID        : {client.client_id}",
            f"Client Name      : {client.name}",
            f"Client Type      : {client.client_type}",
            f"Service Address  : {client.address}",
            "-" * 50,
            "COLLECTION DETAILS",
            f"Collection Date  : {date_str}",
            f"Collection Time  : {time_str}",
            f"Waste Type       : {client.waste_type}",
            f"Waste Quantity   : {client.waste_quantity:.2f} kg",
            f"Rate per kg      : ${unit_rate:.2f} / kg",
            f"Base Charge      : ${base_charge:.2f}",
        ]

        # Add client-specific adjustments / breakdown
        if isinstance(client, HouseholdClient):
            if client.waste_type.lower() in ["recyclable", "organic"]:
                discount = round(base_charge * 0.10, 2)
                lines.append(f"Green Segregation Rebate (10%) : -${discount:.2f}")
            lines.append(f"Household Bin Type             : {client.bin_type}")

        elif isinstance(client, IndustrialClient):
            if client.waste_type.lower() in ["hazardous", "chemical", "toxic"]:
                lines.append("Hazardous Containment Fee      : +$50.00")
            lines.append(f"Environmental Permit #         : {client.permit_number}")
            lines.append(f"Safety Protocol                : {client.safety_protocol}")

        elif isinstance(client, HospitalClient):
            lines.append("Biohazard Sterilization Fee    : +$35.00")
            lines.append(f"Biomedical Category            : {client.biomedical_category}")
            lines.append(f"Compliance Status              : {client.compliance_status}")
            lines.append(f"Disposal Requirements          : {client.disposal_requirements}")
            lines.append(f"Biohazard License #            : {client.license_number}")

        lines.extend([
            "-" * 50,
            f"TOTAL AMOUNT DUE : ${total_bill:.2f}",
            "=" * 50,
            "  Thank you for keeping our city clean and green!",
            "  For support or compliance inquiries: support@smartwaste.city",
            "=" * 50,
        ])

        receipt_content = "\n".join(lines) + "\n"

        try:
            with open(receipt_path, "w", encoding="utf-8") as f:
                f.write(receipt_content)
            logger.info(f"Receipt generated successfully: {receipt_path} (Client: {client.client_id})")
            return receipt_path
        except Exception as e:
            logger.error(f"Failed to write receipt for client {client.client_id}: {e}")
            raise IOError(f"Could not generate receipt file: {e}")
