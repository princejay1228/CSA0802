"""
Test package for Smart Waste Management System.
"""
