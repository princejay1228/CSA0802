"""
Unit and Integration Test Suite for the Smart Waste Management System.
Uses Python's standard unittest framework.
"""
import os
import sys
import json
import unittest
import tempfile
import shutil

# Add project root to sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.waste_client import WasteClient
from models.household import HouseholdClient
from models.industrial import IndustrialClient
from models.hospital import HospitalClient
from managers.client_manager import ClientManager
from managers.schedule_manager import ScheduleManager
from services.billing import BillingService
from services.report_generator import ReportGenerator


class TestSmartWasteManagementSystem(unittest.TestCase):
    """
    Comprehensive tests covering models, managers, billing, receipts, logging, and reporting.
    """

    def setUp(self) -> None:
        # Create a temporary directory for test files to avoid polluting production data
        self.test_dir = tempfile.mkdtemp()
        self.clients_json = os.path.join(self.test_dir, "clients.json")
        self.schedules_json = os.path.join(self.test_dir, "schedules.json")
        self.rates_csv = os.path.join(self.test_dir, "rates.csv")
        self.receipts_dir = os.path.join(self.test_dir, "receipts")
        self.reports_dir = os.path.join(self.test_dir, "reports")

        # Create sample rate CSV
        with open(self.rates_csv, "w", encoding="utf-8") as f:
            f.write(
                "client_type,waste_type,rate_per_kg\n"
                "Household,General,5.0\n"
                "Household,Recyclable,3.0\n"
                "Household,Organic,4.0\n"
                "Industrial,General,10.0\n"
                "Industrial,Hazardous,25.0\n"
                "Hospital,Biomedical,40.0\n"
                "Hospital,General,15.0\n"
            )

        self.client_mgr = ClientManager(file_path=self.clients_json)
        self.schedule_mgr = ScheduleManager(file_path=self.schedules_json)
        self.billing_svc = BillingService(
            rates_csv_path=self.rates_csv,
            receipts_dir=self.receipts_dir
        )
        self.report_gen = ReportGenerator(
            client_manager=self.client_mgr,
            schedule_manager=self.schedule_mgr,
            billing_service=self.billing_svc,
            reports_dir=self.reports_dir
        )

    def tearDown(self) -> None:
        # Clean up temporary test files
        shutil.rmtree(self.test_dir)

    def test_01_models_and_inheritance(self) -> None:
        """
        Verify that base class WasteClient and subclasses properly inherit and instantiate.
        """
        h = HouseholdClient(
            client_id="H100",
            name="Alice Walker",
            address="12 Elm St",
            waste_type="General",
            waste_quantity=20.0,
            household_members=3,
            bin_type="Standard 120L"
        )
        self.assertIsInstance(h, WasteClient)
        self.assertEqual(h.client_type, "Household")
        self.assertIn("Alice Walker", h.get_details())
        self.assertIn("Standard 120L", h.get_details())

        ind = IndustrialClient(
            client_id="I100",
            name="Apex Metalworks",
            address="100 Foundry Rd",
            waste_type="Hazardous",
            waste_quantity=150.0,
            industry_sector="Heavy Metallurgy",
            permit_number="EPA-998"
        )
        self.assertIsInstance(ind, WasteClient)
        self.assertEqual(ind.client_type, "Industrial")
        self.assertIn("EPA-998", ind.get_details())

        hosp = HospitalClient(
            client_id="M100",
            name="County Medical Center",
            address="50 Health Ave",
            waste_type="Biomedical",
            waste_quantity=60.0,
            biomedical_category="Yellow (Anatomical)",
            compliance_status="Compliant",
            license_number="BIO-887"
        )
        self.assertIsInstance(hosp, WasteClient)
        self.assertEqual(hosp.client_type, "Hospital")
        self.assertEqual(hosp.compliance_status, "Compliant")

    def test_02_csv_rate_loading(self) -> None:
        """
        Verify that rates are dynamically parsed from CSV file.
        """
        rate_table = self.billing_svc.load_rates_from_csv()
        self.assertIn(("household", "general"), rate_table)
        self.assertEqual(rate_table[("household", "general")], 5.0)
        self.assertEqual(rate_table[("industrial", "hazardous")], 25.0)
        self.assertEqual(rate_table[("hospital", "biomedical")], 40.0)

    def test_03_billing_calculation_with_subclass_rules(self) -> None:
        """
        Verify polymorphic billing calculation logic.
        """
        # 1. Household General: 20kg * $5 = $100.00
        h_gen = HouseholdClient("H1", "Test", "Addr", "General", 20.0)
        self.assertEqual(self.billing_svc.calculate_bill_for_client(h_gen), 100.0)

        # 2. Household Recyclable (10% rebate): 10kg * $3 = $30 -> 10% off = $27.00
        h_rec = HouseholdClient("H2", "Green Test", "Addr", "Recyclable", 10.0)
        self.assertEqual(self.billing_svc.calculate_bill_for_client(h_rec), 27.0)

        # 3. Industrial Hazardous (+$50 containment): 10kg * $25 = $250 + $50 = $300.00
        ind_haz = IndustrialClient("I1", "ChemCorp", "Addr", "Hazardous", 10.0)
        self.assertEqual(self.billing_svc.calculate_bill_for_client(ind_haz), 300.0)

        # 4. Hospital Biomedical (+$35 biohazard sterilization): 10kg * $40 = $400 + $35 = $435.00
        hosp = HospitalClient("M1", "Care Clinic", "Addr", "Biomedical", 10.0)
        self.assertEqual(self.billing_svc.calculate_bill_for_client(hosp), 435.0)

    def test_04_schedule_manager_json(self) -> None:
        """
        Verify JSON file persistence and schedule lifecycle in ScheduleManager.
        """
        # Add schedule
        sch = self.schedule_mgr.add_schedule(
            client_id="H100",
            collection_date="2026-09-01",
            collection_time="08:30",
            frequency="Weekly"
        )
        self.assertIsNotNone(sch)
        sch_id = sch["schedule_id"]

        # View and find
        all_schedules = self.schedule_mgr.get_all_schedules()
        self.assertEqual(len(all_schedules), 1)

        found = self.schedule_mgr.find_schedule_by_id(sch_id)
        self.assertIsNotNone(found)
        self.assertEqual(found["client_id"], "H100")

        # Update schedule
        self.schedule_mgr.update_schedule(sch_id, collection_time="09:00", status="In-Progress")
        updated = self.schedule_mgr.find_schedule_by_id(sch_id)
        self.assertEqual(updated["collection_time"], "09:00")
        self.assertEqual(updated["status"], "In-Progress")

        # Complete collection
        self.schedule_mgr.complete_collection(sch_id)
        completed = self.schedule_mgr.find_schedule_by_id(sch_id)
        self.assertEqual(completed["status"], "Completed")

        # Delete schedule
        self.schedule_mgr.delete_schedule(sch_id)
        self.assertEqual(len(self.schedule_mgr.get_all_schedules()), 0)

    def test_05_client_manager_json_persistence(self) -> None:
        """
        Verify JSON file persistence and polymorphism in ClientManager.
        """
        c1 = HouseholdClient("H200", "Bob", "1 Main St", "General", 15.0)
        c2 = HospitalClient("M200", "Metro Health", "2 Main St", "Biomedical", 50.0, compliance_status="Pending Verification")

        self.client_mgr.register_client(c1)
        self.client_mgr.register_client(c2)

        # Reload from disk
        reloaded = self.client_mgr.load_clients()
        self.assertEqual(len(reloaded), 2)
        
        # Verify polymorphic types restored
        types = {c.client_id: type(c) for c in reloaded}
        self.assertEqual(types["H200"], HouseholdClient)
        self.assertEqual(types["M200"], HospitalClient)

        # Update hospital compliance
        self.client_mgr.update_hospital_compliance("M200", "Compliant")
        updated_hosp = self.client_mgr.find_client("M200")
        self.assertEqual(updated_hosp.compliance_status, "Compliant")

    def test_06_receipt_text_file_generation(self) -> None:
        """
        Verify receipts are saved as properly formatted .txt files in receipts folder.
        """
        client = HospitalClient(
            client_id="M300",
            name="General Med",
            address="77 Health Way",
            waste_type="Biomedical",
            waste_quantity=10.0,
            compliance_status="Compliant"
        )
        receipt_path = self.billing_svc.generate_receipt(client, collection_date="2026-08-25", collection_time="10:00")
        
        self.assertTrue(os.path.exists(receipt_path))
        with open(receipt_path, "r", encoding="utf-8") as f:
            content = f.read()
            self.assertIn("SMART WASTE MANAGEMENT SYSTEM", content)
            self.assertIn("OFFICIAL PAYMENT RECEIPT", content)
            self.assertIn("M300", content)
            self.assertIn("General Med", content)
            self.assertIn("$435.00", content)
            self.assertIn("Compliant", content)

    def test_07_summary_report_generation(self) -> None:
        """
        Verify dynamic report creation from stored data into reports folder.
        """
        # Register clients
        self.client_mgr.register_client(HouseholdClient("H1", "H-User", "Street 1", "General", 10.0))
        self.client_mgr.register_client(IndustrialClient("I1", "I-Corp", "Street 2", "Hazardous", 50.0))
        self.client_mgr.register_client(HospitalClient("M1", "M-Clinic", "Street 3", "Biomedical", 20.0, compliance_status="Non-Compliant"))

        # Add schedule
        self.schedule_mgr.add_schedule("H1", "2026-08-26", "08:00", status="Completed")
        self.schedule_mgr.add_schedule("M1", "2026-08-27", "09:00", status="Scheduled")

        report_path = self.report_gen.generate_summary_report("test_report.txt")
        self.assertTrue(os.path.exists(report_path))

        with open(report_path, "r", encoding="utf-8") as f:
            report_text = f.read()
            self.assertIn("Total Registered Clients    : 3", report_text)
            self.assertIn("Household Clients         : 1", report_text)
            self.assertIn("Industrial Clients        : 1", report_text)
            self.assertIn("Hospital/Medical Clients  : 1", report_text)
            self.assertIn("Total Waste Volume Tracked  : 80.00 kg", report_text)
            self.assertIn("Completed Pickups         : 1", report_text)
            self.assertIn("Pending/Scheduled Pickups : 1", report_text)
            self.assertIn("NON-COMPLIANT: ID=M1", report_text)


if __name__ == "__main__":
    unittest.main()
