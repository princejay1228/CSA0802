"""
Smart Waste Management System - Main Entry Point.
Provides an interactive command-line interface (CLI) for municipal waste operations.
"""
import os
import sys
import logging
from datetime import datetime
from typing import Optional

# Set up project root in sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from models.waste_client import WasteClient
from models.household import HouseholdClient
from models.industrial import IndustrialClient
from models.hospital import HospitalClient
from managers.client_manager import ClientManager
from managers.schedule_manager import ScheduleManager
from services.billing import BillingService
from services.report_generator import ReportGenerator


def setup_logging(log_file: str = "logs/system.log") -> logging.Logger:
    """
    Configures Python logging with FileHandler to record all system activities.
    """
    log_dir = os.path.dirname(log_file)
    if log_dir and not os.path.exists(log_dir):
        os.makedirs(log_dir, exist_ok=True)

    logger = logging.getLogger("SmartWasteManager")
    logger.setLevel(logging.INFO)

    # Avoid duplicate handlers if re-initialized
    if not logger.handlers:
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setLevel(logging.INFO)
        formatter = logging.Formatter(
            "%(asctime)s [%(levelname)s] [%(filename)s:%(lineno)d] - %(message)s"
        )
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    logger.info("=" * 60)
    logger.info("Smart Waste Management System session initialized.")
    return logger


def display_menu() -> None:
    """
    Renders the primary application menu.
    """
    print("\n" + "=" * 48)
    print("       SMART WASTE MANAGEMENT SYSTEM")
    print("=" * 48)
    print(" 1. Register Client")
    print(" 2. View Clients")
    print(" 3. Add Collection Schedule")
    print(" 4. View Collection Schedules")
    print(" 5. Update Collection Schedule")
    print(" 6. Calculate Bill")
    print(" 7. Generate Receipt")
    print(" 8. Complete Collection")
    print(" 9. Check Hospital Compliance")
    print(" 10. Generate Summary Report")
    print(" 11. Exit")
    print("=" * 48)


def get_non_empty_input(prompt: str) -> str:
    """
    Helper to prompt user until a non-empty string is provided.
    """
    while True:
        value = input(prompt).strip()
        if value:
            return value
        print("  [!] Error: Input cannot be empty. Please try again.")


def get_positive_float(prompt: str) -> float:
    """
    Helper to prompt user until a positive float is entered.
    """
    while True:
        raw = input(prompt).strip()
        try:
            val = float(raw)
            if val >= 0:
                return val
            print("  [!] Error: Value cannot be negative.")
        except ValueError:
            print("  [!] Error: Please enter a valid numerical value.")


def register_client_flow(client_manager: ClientManager, logger: logging.Logger) -> None:
    """
    Workflow for registering a new client (Household, Industrial, or Hospital).
    """
    print("\n--- [REGISTER NEW CLIENT] ---")
    print("Select Client Classification:")
    print("  1. Household Client")
    print("  2. Industrial Client")
    print("  3. Hospital / Medical Client")
    choice = input("Enter choice (1-3): ").strip()

    if choice not in ["1", "2", "3"]:
        print("  [!] Invalid client classification selected.")
        logger.warning(f"Invalid client classification choice attempted: '{choice}'")
        return

    client_id = get_non_empty_input("Enter Unique Client ID (e.g., H003, I003, M003): ").upper()

    # Check for existing ID
    if client_manager.find_client(client_id):
        print(f"  [!] Error: Client ID '{client_id}' is already registered in the system.")
        logger.warning(f"Registration rejected: Client ID '{client_id}' already exists.")
        return

    name = get_non_empty_input("Enter Client/Facility Name: ")
    address = get_non_empty_input("Enter Service Address: ")

    new_client: Optional[WasteClient] = None

    if choice == "1":
        print("\nCommon Household Waste Types: General, Recyclable, Organic")
        waste_type = get_non_empty_input("Enter Waste Type: ").capitalize()
        waste_quantity = get_positive_float("Enter Waste Quantity (in kg): ")
        members_str = input("Enter Household Members count [Default: 4]: ").strip()
        members = int(members_str) if members_str.isdigit() else 4
        bin_type = input("Enter Bin Type (e.g. Standard 120L, Large 240L) [Default: Standard 120L]: ").strip() or "Standard 120L"

        new_client = HouseholdClient(
            client_id=client_id,
            name=name,
            address=address,
            waste_type=waste_type,
            waste_quantity=waste_quantity,
            household_members=members,
            bin_type=bin_type
        )

    elif choice == "2":
        print("\nCommon Industrial Waste Types: General, Hazardous, Chemical, Toxic")
        waste_type = get_non_empty_input("Enter Waste Type: ").capitalize()
        waste_quantity = get_positive_float("Enter Waste Quantity (in kg): ")
        sector = input("Enter Industry Sector (e.g. Manufacturing, Petrochemical) [Default: Manufacturing]: ").strip() or "Manufacturing"
        permit = input("Enter EPA / Environmental Permit # [Default: IND-PERMIT-000]: ").strip() or "IND-PERMIT-000"
        safety = input("Enter Safety Containment Protocol [Default: Standard Industrial]: ").strip() or "Standard Industrial"

        new_client = IndustrialClient(
            client_id=client_id,
            name=name,
            address=address,
            waste_type=waste_type,
            waste_quantity=waste_quantity,
            industry_sector=sector,
            permit_number=permit,
            safety_protocol=safety
        )

    elif choice == "3":
        print("\nCommon Hospital Waste Types: Biomedical, Sharps, Pathological, General")
        waste_type = get_non_empty_input("Enter Waste Type: ").capitalize()
        waste_quantity = get_positive_float("Enter Waste Quantity (in kg): ")
        print("Biomedical Categories: 1. Yellow (Anatomical) | 2. Red (Contaminated) | 3. White (Sharps) | 4. Blue (Glass/Meds)")
        cat_input = input("Select Category (1-4 or custom description) [Default: 1]: ").strip()
        categories = {
            "1": "Yellow (Anatomical & Chemotherapy)",
            "2": "Red (Contaminated Plastics & Tubing)",
            "3": "White (Puncture-Proof Sharps/Needles)",
            "4": "Blue (Glassware & Expired Medicine)"
        }
        category = categories.get(cat_input, cat_input if cat_input else "Yellow (Anatomical & Chemotherapy)")

        print("Compliance Statuses: 1. Compliant | 2. Pending Verification | 3. Non-Compliant")
        status_input = input("Select Initial Compliance Status (1-3) [Default: 1]: ").strip()
        status_map = {"1": "Compliant", "2": "Pending Verification", "3": "Non-Compliant"}
        status = status_map.get(status_input, "Compliant")

        disposal = input("Enter Disposal Requirements [Default: High-Temperature Incineration (1100°C)]: ").strip() or "High-Temperature Incineration (1100°C)"
        license_no = input("Enter Biohazard License # [Default: MED-BIO-001]: ").strip() or "MED-BIO-001"

        new_client = HospitalClient(
            client_id=client_id,
            name=name,
            address=address,
            waste_type=waste_type,
            waste_quantity=waste_quantity,
            biomedical_category=category,
            compliance_status=status,
            disposal_requirements=disposal,
            license_number=license_no
        )

    if new_client:
        if client_manager.register_client(new_client):
            print(f"\n  [✓] Success: Client '{new_client.name}' (ID: {new_client.client_id}) registered successfully.")
            print(f"  [✓] Persisted to data/clients.json and logged to system.log")
        else:
            print(f"\n  [!] Failed to save client '{client_id}'.")


def view_clients_flow(client_manager: ClientManager) -> None:
    """
    Displays all registered clients with their polymorphic details.
    """
    print("\n--- [REGISTERED CLIENTS DIRECTORY] ---")
    clients = client_manager.get_all_clients()
    if not clients:
        print("  No registered clients found in data/clients.json.")
        return

    print(f"Total Registered Clients: {len(clients)}\n")
    for idx, client in enumerate(clients, start=1):
        print(f"[{idx}] {client.client_type.upper()} CLIENT - {client.client_id}")
        print("  " + "\n  ".join(client.get_details().split("\n")))
        print("  " + "-" * 44)


def add_schedule_flow(
    client_manager: ClientManager,
    schedule_manager: ScheduleManager,
    logger: logging.Logger
) -> None:
    """
    Creates a new collection schedule linked to a valid client.
    """
    print("\n--- [ADD COLLECTION SCHEDULE] ---")
    client_id = get_non_empty_input("Enter Client ID for this schedule: ").upper()
    client = client_manager.find_client(client_id)

    if not client:
        print(f"  [!] Error: Client ID '{client_id}' not found. Please register client first.")
        logger.warning(f"Schedule creation failed: Client '{client_id}' does not exist.")
        return

    print(f"  Scheduling pickup for: {client.name} ({client.client_type} - {client.waste_type} Waste)")
    date_str = get_non_empty_input("Enter Collection Date (YYYY-MM-DD): ")
    time_str = get_non_empty_input("Enter Collection Time (HH:MM): ")
    print("Frequency Options: 1. Daily | 2. Weekly | 3. Bi-Weekly | 4. Monthly | 5. On-Demand")
    freq_choice = input("Select Frequency (1-5) [Default: 2]: ").strip()
    freq_map = {"1": "Daily", "2": "Weekly", "3": "Bi-Weekly", "4": "Monthly", "5": "On-Demand"}
    frequency = freq_map.get(freq_choice, "Weekly")

    created = schedule_manager.add_schedule(
        client_id=client_id,
        collection_date=date_str,
        collection_time=time_str,
        frequency=frequency,
        status="Scheduled"
    )

    if created:
        print(f"\n  [✓] Success: Collection scheduled! ID: {created['schedule_id']}")
        print(f"      Client : {client_id} ({client.name})")
        print(f"      Date   : {date_str} at {time_str} ({frequency})")
    else:
        print("  [!] Failed to create schedule.")


def view_schedules_flow(schedule_manager: ScheduleManager) -> None:
    """
    Renders all collection schedules from JSON file.
    """
    print("\n--- [COLLECTION SCHEDULES MANIFEST] ---")
    schedules = schedule_manager.get_all_schedules()
    if not schedules:
        print("  No schedules found in data/schedules.json.")
        return

    header = f"{'Sch ID':<10} {'Client ID':<10} {'Date':<12} {'Time':<8} {'Frequency':<12} {'Status':<12}"
    print(header)
    print("-" * len(header))
    for s in schedules:
        print(
            f"{s.get('schedule_id', 'N/A'):<10} "
            f"{s.get('client_id', 'N/A'):<10} "
            f"{s.get('collection_date', 'N/A'):<12} "
            f"{s.get('collection_time', 'N/A'):<8} "
            f"{s.get('frequency', 'N/A'):<12} "
            f"{s.get('status', 'N/A'):<12}"
        )


def update_schedule_flow(schedule_manager: ScheduleManager, logger: logging.Logger) -> None:
    """
    Updates schedule date, time, frequency, or status.
    """
    print("\n--- [UPDATE COLLECTION SCHEDULE] ---")
    schedule_id = get_non_empty_input("Enter Schedule ID to update (e.g. SCH-001): ").upper()
    existing = schedule_manager.find_schedule_by_id(schedule_id)

    if not existing:
        print(f"  [!] Error: Schedule ID '{schedule_id}' not found.")
        logger.warning(f"Update attempted on non-existent schedule '{schedule_id}'")
        return

    print(f"Current Schedule: Client={existing.get('client_id')}, Date={existing.get('collection_date')}, Time={existing.get('collection_time')}, Status={existing.get('status')}")
    print("Leave fields blank to retain existing values.")

    new_date = input(f"New Date [{existing.get('collection_date')}]: ").strip() or None
    new_time = input(f"New Time [{existing.get('collection_time')}]: ").strip() or None
    new_freq = input(f"New Frequency [{existing.get('frequency')}]: ").strip() or None
    
    print("Status Options: 1. Scheduled | 2. In-Progress | 3. Completed | 4. Cancelled")
    status_choice = input(f"Select Status (1-4) or press Enter to keep [{existing.get('status')}]: ").strip()
    status_map = {"1": "Scheduled", "2": "In-Progress", "3": "Completed", "4": "Cancelled"}
    new_status = status_map.get(status_choice, None)

    success = schedule_manager.update_schedule(
        schedule_id=schedule_id,
        collection_date=new_date,
        collection_time=new_time,
        frequency=new_freq,
        status=new_status
    )

    if success:
        print(f"\n  [✓] Success: Schedule '{schedule_id}' updated successfully.")
    else:
        print(f"  [!] Failed to update schedule '{schedule_id}'.")


def calculate_bill_flow(
    client_manager: ClientManager,
    billing_service: BillingService,
    logger: logging.Logger
) -> None:
    """
    Calculates bill for a client by applying CSV rates and polymorphic rules.
    """
    print("\n--- [CALCULATE CLIENT BILL] ---")
    client_id = get_non_empty_input("Enter Client ID: ").upper()
    client = client_manager.find_client(client_id)

    if not client:
        print(f"  [!] Error: Client ID '{client_id}' not found.")
        logger.warning(f"Bill calculation aborted: Client '{client_id}' not found.")
        return

    rate_per_kg = billing_service.get_rate_per_kg(client.client_type, client.waste_type)
    total_amount = billing_service.calculate_bill_for_client(client)
    base_charge = client.waste_quantity * rate_per_kg

    print("\n" + "=" * 44)
    print("         BILLING COMPUTATION SUMMARY")
    print("=" * 44)
    print(f"Client ID        : {client.client_id}")
    print(f"Client Name      : {client.name}")
    print(f"Client Type      : {client.client_type}")
    print(f"Waste Type       : {client.waste_type}")
    print(f"Waste Quantity   : {client.waste_quantity:.2f} kg")
    print(f"Rate from CSV    : ${rate_per_kg:.2f} / kg")
    print(f"Base Cost        : ${base_charge:.2f}")

    if isinstance(client, HouseholdClient) and client.waste_type.lower() in ["recyclable", "organic"]:
        rebate = round(base_charge * 0.10, 2)
        print(f"Green Segregation Rebate (10%): -${rebate:.2f}")
    elif isinstance(client, IndustrialClient) and client.waste_type.lower() in ["hazardous", "chemical", "toxic"]:
        print(f"Hazardous Containment Fee: +$50.00")
    elif isinstance(client, HospitalClient):
        print(f"Biohazard Sterilization Fee: +$35.00")
        print(f"Compliance Status: {client.compliance_status}")

    print("-" * 44)
    print(f"TOTAL BILL DUE   : ${total_amount:.2f}")
    print("=" * 44)


def generate_receipt_flow(
    client_manager: ClientManager,
    schedule_manager: ScheduleManager,
    billing_service: BillingService,
    logger: logging.Logger
) -> None:
    """
    Generates a .txt receipt file in receipts/ folder.
    """
    print("\n--- [GENERATE RECEIPT FILE] ---")
    client_id = get_non_empty_input("Enter Client ID: ").upper()
    client = client_manager.find_client(client_id)

    if not client:
        print(f"  [!] Error: Client ID '{client_id}' not found.")
        logger.warning(f"Receipt generation aborted: Client '{client_id}' not found.")
        return

    # Check if there is an associated schedule
    schedules = schedule_manager.find_schedules_by_client(client_id)
    coll_date = schedules[-1].get("collection_date") if schedules else None
    coll_time = schedules[-1].get("collection_time") if schedules else None

    try:
        receipt_path = billing_service.generate_receipt(
            client=client,
            collection_date=coll_date,
            collection_time=coll_time
        )
        print(f"\n  [✓] Receipt generated successfully!")
        print(f"  [✓] Saved to File: {receipt_path}")
        print("\n--- RECEIPT PREVIEW ---")
        with open(receipt_path, "r", encoding="utf-8") as f:
            print(f.read())
    except Exception as e:
        print(f"  [!] Error generating receipt: {e}")
        logger.error(f"Receipt generation error for {client_id}: {e}")


def complete_collection_flow(
    schedule_manager: ScheduleManager,
    logger: logging.Logger
) -> None:
    """
    Marks a collection pickup as Completed.
    """
    print("\n--- [COMPLETE COLLECTION PICKUP] ---")
    schedule_id = get_non_empty_input("Enter Schedule ID to mark Completed (e.g. SCH-001): ").upper()
    sch = schedule_manager.find_schedule_by_id(schedule_id)

    if not sch:
        print(f"  [!] Error: Schedule ID '{schedule_id}' not found.")
        logger.warning(f"Complete collection failed: Schedule '{schedule_id}' not found.")
        return

    if schedule_manager.complete_collection(schedule_id):
        print(f"\n  [✓] Success: Schedule '{schedule_id}' for Client '{sch.get('client_id')}' marked as 'Completed'.")
        print("  [✓] Logged event to system.log")
    else:
        print(f"  [!] Failed to update status for schedule '{schedule_id}'.")


def check_hospital_compliance_flow(
    client_manager: ClientManager,
    logger: logging.Logger
) -> None:
    """
    Inspects and manages regulatory compliance for healthcare/hospital facilities.
    """
    print("\n--- [HOSPITAL BIOMEDICAL COMPLIANCE AUDIT] ---")
    all_clients = client_manager.get_all_clients()
    hospitals = [c for c in all_clients if isinstance(c, HospitalClient)]

    if not hospitals:
        print("  No hospital clients currently registered.")
        return

    print(f"Registered Medical Facilities ({len(hospitals)}):\n")
    for h in hospitals:
        status_flag = "✓" if h.compliance_status == "Compliant" else "!"
        print(f"  [{status_flag}] ID: {h.client_id} | Name: {h.name}")
        print(f"      Biomedical Category : {h.biomedical_category}")
        print(f"      Compliance Status   : {h.compliance_status}")
        print(f"      Disposal Protocol   : {h.disposal_requirements}")
        print(f"      License #           : {h.license_number}")
        print("  " + "-" * 50)

    print("\nActions:")
    print("  1. Update a Hospital's Compliance Status")
    print("  2. Return to Main Menu")
    action = input("Enter choice (1-2): ").strip()

    if action == "1":
        h_id = get_non_empty_input("Enter Hospital Client ID to update: ").upper()
        h_client = client_manager.find_client(h_id)
        if not h_client or not isinstance(h_client, HospitalClient):
            print(f"  [!] Error: Client '{h_id}' is not a registered Hospital.")
            logger.warning(f"Compliance audit failed: '{h_id}' is not a HospitalClient.")
            return

        print("\nSelect New Compliance Status:")
        print("  1. Compliant")
        print("  2. Pending Verification")
        print("  3. Non-Compliant")
        c_choice = input("Enter selection (1-3): ").strip()
        status_map = {"1": "Compliant", "2": "Pending Verification", "3": "Non-Compliant"}
        new_status = status_map.get(c_choice)

        if new_status:
            if client_manager.update_hospital_compliance(h_id, new_status):
                print(f"\n  [✓] Success: Updated {h_client.name} compliance to '{new_status}'.")
                print("  [✓] Logged to system.log and updated in clients.json.")
            else:
                print(f"  [!] Failed to update compliance for '{h_id}'.")
        else:
            print("  [!] Invalid status selected.")


def generate_summary_report_flow(
    report_generator: ReportGenerator,
    logger: logging.Logger
) -> None:
    """
    Generates dynamic summary report in reports/summary_report.txt.
    """
    print("\n--- [GENERATE SUMMARY REPORT] ---")
    try:
        report_path = report_generator.generate_summary_report()
        print(f"  [✓] Success! Dynamic summary report generated.")
        print(f"  [✓] Report File: {report_path}")
        print("\n--- REPORT PREVIEW ---")
        with open(report_path, "r", encoding="utf-8") as f:
            print(f.read())
    except Exception as e:
        print(f"  [!] Error generating summary report: {e}")
        logger.error(f"Report generation error: {e}")


def main() -> None:
    """
    Main application loop.
    """
    logger = setup_logging()

    # Instantiate core managers & services
    client_manager = ClientManager(file_path="data/clients.json")
    schedule_manager = ScheduleManager(file_path="data/schedules.json")
    billing_service = BillingService(rates_csv_path="data/rates.csv", receipts_dir="receipts")
    report_generator = ReportGenerator(
        client_manager=client_manager,
        schedule_manager=schedule_manager,
        billing_service=billing_service,
        reports_dir="reports"
    )

    print("==================================================")
    print(" Welcome to Smart Waste Management System v1.0")
    print(" Urban Municipal Operations & Compliance Control")
    print("==================================================")

    while True:
        try:
            display_menu()
            choice = input("Enter your choice (1-11): ").strip()

            if choice == "1":
                register_client_flow(client_manager, logger)
            elif choice == "2":
                view_clients_flow(client_manager)
            elif choice == "3":
                add_schedule_flow(client_manager, schedule_manager, logger)
            elif choice == "4":
                view_schedules_flow(schedule_manager)
            elif choice == "5":
                update_schedule_flow(schedule_manager, logger)
            elif choice == "6":
                calculate_bill_flow(client_manager, billing_service, logger)
            elif choice == "7":
                generate_receipt_flow(client_manager, schedule_manager, billing_service, logger)
            elif choice == "8":
                complete_collection_flow(schedule_manager, logger)
            elif choice == "9":
                check_hospital_compliance_flow(client_manager, logger)
            elif choice == "10":
                generate_summary_report_flow(report_generator, logger)
            elif choice == "11":
                print("\nExiting Smart Waste Management System. Goodbye!")
                logger.info("Application closed gracefully by user.")
                break
            else:
                print("\n  [!] Invalid choice. Please enter a number between 1 and 11.")
                logger.warning(f"User entered invalid menu choice: '{choice}'")

            input("\nPress [Enter] to return to the menu...")

        except KeyboardInterrupt:
            print("\n\nOperation interrupted by user. Exiting gracefully...")
            logger.info("Application terminated via KeyboardInterrupt.")
            break
        except Exception as e:
            print(f"\n  [!] An unexpected error occurred: {e}")
            logger.error(f"Unhandled exception in main loop: {e}", exc_info=True)
            input("\nPress [Enter] to continue...")


if __name__ == "__main__":
    main()
