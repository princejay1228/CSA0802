"""
Household Client model derived from WasteClient.
"""
from typing import Dict, Any
from .waste_client import WasteClient


class HouseholdClient(WasteClient):
    """
    Represents residential/household waste clients.
    """

    def __init__(
        self,
        client_id: str,
        name: str,
        address: str,
        waste_type: str,
        waste_quantity: float,
        household_members: int = 4,
        bin_type: str = "Standard 120L"
    ) -> None:
        super().__init__(
            client_id=client_id,
            name=name,
            address=address,
            waste_type=waste_type,
            waste_quantity=waste_quantity,
            client_type="Household"
        )
        self.household_members = int(household_members)
        self.bin_type = bin_type

    def get_details(self) -> str:
        base_details = super().get_details()
        return (
            f"{base_details}\n"
            f"Household Members: {self.household_members}\n"
            f"Bin Type: {self.bin_type}"
        )

    def calculate_bill(self, rate_table: Dict[str, float]) -> float:
        """
        Calculates household bill. Applies a 10% green rebate for recyclable/organic waste.
        """
        base_bill = super().calculate_bill(rate_table)
        if self._waste_type.lower() in ["recyclable", "organic"]:
            # Green incentive: 10% discount on segregated recycling/organic waste
            return round(base_bill * 0.90, 2)
        return round(base_bill, 2)

    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data.update({
            "household_members": self.household_members,
            "bin_type": self.bin_type
        })
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "HouseholdClient":
        return cls(
            client_id=data["client_id"],
            name=data["name"],
            address=data["address"],
            waste_type=data["waste_type"],
            waste_quantity=data["waste_quantity"],
            household_members=data.get("household_members", 4),
            bin_type=data.get("bin_type", "Standard 120L")
        )
