"""
Base class for all waste management clients.
Demonstrates Object-Oriented Programming (OOP), encapsulation, and polymorphism.
"""
from abc import ABC
from typing import Dict, Any


class WasteClient(ABC):
    """
    Abstract base class representing a generic waste management client.
    """

    def __init__(
        self,
        client_id: str,
        name: str,
        address: str,
        waste_type: str,
        waste_quantity: float,
        client_type: str = "Standard"
    ) -> None:
        self._client_id = client_id.strip()
        self._name = name.strip()
        self._address = address.strip()
        self._waste_type = waste_type.strip()
        self._waste_quantity = float(waste_quantity)
        self._client_type = client_type

    @property
    def client_id(self) -> str:
        return self._client_id

    @property
    def name(self) -> str:
        return self._name

    @property
    def address(self) -> str:
        return self._address

    @property
    def waste_type(self) -> str:
        return self._waste_type

    @property
    def waste_quantity(self) -> float:
        return self._waste_quantity

    @waste_quantity.setter
    def waste_quantity(self, value: float) -> None:
        if value < 0:
            raise ValueError("Waste quantity cannot be negative.")
        self._waste_quantity = float(value)

    @property
    def client_type(self) -> str:
        return self._client_type

    def get_details(self) -> str:
        """
        Returns formatted details of the client.
        """
        return (
            f"Client ID: {self._client_id}\n"
            f"Name: {self._name}\n"
            f"Type: {self._client_type}\n"
            f"Address: {self._address}\n"
            f"Waste Type: {self._waste_type}\n"
            f"Waste Quantity: {self._waste_quantity:.2f} kg"
        )

    def calculate_bill(self, rate_table: Dict[str, float]) -> float:
        """
        Calculates billing amount using rates loaded from CSV.
        Base formula: quantity * rate_per_kg.
        Subclasses can override to add specific disposal fees or surcharges.
        """
        rate_key = (self._client_type.lower(), self._waste_type.lower())
        rate = rate_table.get(rate_key)
        if rate is None:
            # Fallback to general rate or zero
            general_key = (self._client_type.lower(), "general")
            rate = rate_table.get(general_key, 0.0)
        return self._waste_quantity * rate

    def schedule_collection(
        self,
        date_str: str,
        time_str: str,
        frequency: str = "Weekly"
    ) -> Dict[str, Any]:
        """
        Creates a dictionary record for a collection schedule.
        """
        return {
            "client_id": self._client_id,
            "client_name": self._name,
            "client_type": self._client_type,
            "collection_date": date_str,
            "collection_time": time_str,
            "frequency": frequency,
            "status": "Scheduled"
        }

    def to_dict(self) -> Dict[str, Any]:
        """
        Serializes client object to a dictionary for JSON persistence.
        """
        return {
            "client_id": self._client_id,
            "name": self._name,
            "address": self._address,
            "waste_type": self._waste_type,
            "waste_quantity": self._waste_quantity,
            "client_type": self._client_type,
        }

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} id={self._client_id} name={self._name}>"
