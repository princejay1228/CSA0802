"""
Hospital Client model derived from WasteClient.
Implements biomedical waste categorization and regulatory compliance tracking.
"""
from typing import Dict, Any
from .waste_client import WasteClient


class HospitalClient(WasteClient):
    """
    Represents healthcare and hospital facilities with strict biomedical waste compliance.
    """

    VALID_COMPLIANCE_STATUSES = ["Compliant", "Pending Verification", "Non-Compliant"]

    def __init__(
        self,
        client_id: str,
        name: str,
        address: str,
        waste_type: str,
        waste_quantity: float,
        biomedical_category: str = "Yellow (Anatomical & Chemotherapy)",
        compliance_status: str = "Compliant",
        disposal_requirements: str = "High-Temperature Incineration (1100°C)",
        license_number: str = "MED-BIO-001"
    ) -> None:
        super().__init__(
            client_id=client_id,
            name=name,
            address=address,
            waste_type=waste_type,
            waste_quantity=waste_quantity,
            client_type="Hospital"
        )
        self.biomedical_category = biomedical_category
        self.compliance_status = (
            compliance_status if compliance_status in self.VALID_COMPLIANCE_STATUSES
            else "Pending Verification"
        )
        self.disposal_requirements = disposal_requirements
        self.license_number = license_number

    def get_details(self) -> str:
        base_details = super().get_details()
        return (
            f"{base_details}\n"
            f"Biomedical Category: {self.biomedical_category}\n"
            f"Compliance Status: {self.compliance_status}\n"
            f"Disposal Requirements: {self.disposal_requirements}\n"
            f"Biohazard License #: {self.license_number}"
        )

    def calculate_bill(self, rate_table: Dict[str, float]) -> float:
        """
        Calculates hospital billing with biohazard sterilization and regulatory manifest fee.
        """
        base_bill = super().calculate_bill(rate_table)
        biohazard_sterilization_fee = 35.00  # Mandatory autoclave / incinerator fee per pickup
        total = base_bill + biohazard_sterilization_fee
        return round(total, 2)

    def update_compliance_status(self, new_status: str) -> bool:
        """
        Updates hospital compliance status.
        """
        if new_status in self.VALID_COMPLIANCE_STATUSES:
            self.compliance_status = new_status
            return True
        return False

    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data.update({
            "biomedical_category": self.biomedical_category,
            "compliance_status": self.compliance_status,
            "disposal_requirements": self.disposal_requirements,
            "license_number": self.license_number
        })
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "HospitalClient":
        return cls(
            client_id=data["client_id"],
            name=data["name"],
            address=data["address"],
            waste_type=data["waste_type"],
            waste_quantity=data["waste_quantity"],
            biomedical_category=data.get("biomedical_category", "Yellow (Anatomical & Chemotherapy)"),
            compliance_status=data.get("compliance_status", "Compliant"),
            disposal_requirements=data.get("disposal_requirements", "High-Temperature Incineration (1100°C)"),
            license_number=data.get("license_number", "MED-BIO-001")
        )
