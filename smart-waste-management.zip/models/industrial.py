"""
Industrial Client model derived from WasteClient.
"""
from typing import Dict, Any
from .waste_client import WasteClient


class IndustrialClient(WasteClient):
    """
    Represents industrial and commercial manufacturing waste clients.
    """

    def __init__(
        self,
        client_id: str,
        name: str,
        address: str,
        waste_type: str,
        waste_quantity: float,
        industry_sector: str = "Manufacturing",
        permit_number: str = "IND-PERMIT-000",
        safety_protocol: str = "Standard Industrial"
    ) -> None:
        super().__init__(
            client_id=client_id,
            name=name,
            address=address,
            waste_type=waste_type,
            waste_quantity=waste_quantity,
            client_type="Industrial"
        )
        self.industry_sector = industry_sector
        self.permit_number = permit_number
        self.safety_protocol = safety_protocol

    def get_details(self) -> str:
        base_details = super().get_details()
        return (
            f"{base_details}\n"
            f"Industry Sector: {self.industry_sector}\n"
            f"EPA/Env Permit #: {self.permit_number}\n"
            f"Safety Protocol: {self.safety_protocol}"
        )

    def calculate_bill(self, rate_table: Dict[str, float]) -> float:
        """
        Calculates industrial bill. Adds a safety containment surcharge for hazardous/chemical materials.
        """
        base_bill = super().calculate_bill(rate_table)
        surcharge = 0.0
        if self._waste_type.lower() in ["hazardous", "chemical", "toxic"]:
            # Environmental handling & containment fixed fee per collection
            surcharge = 50.00
        return round(base_bill + surcharge, 2)

    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data.update({
            "industry_sector": self.industry_sector,
            "permit_number": self.permit_number,
            "safety_protocol": self.safety_protocol
        })
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "IndustrialClient":
        return cls(
            client_id=data["client_id"],
            name=data["name"],
            address=data["address"],
            waste_type=data["waste_type"],
            waste_quantity=data["waste_quantity"],
            industry_sector=data.get("industry_sector", "Manufacturing"),
            permit_number=data.get("permit_number", "IND-PERMIT-000"),
            safety_protocol=data.get("safety_protocol", "Standard Industrial")
        )
