"""
Models package for Smart Waste Management System.
Exports WasteClient, HouseholdClient, IndustrialClient, and HospitalClient.
"""
from .waste_client import WasteClient
from .household import HouseholdClient
from .industrial import IndustrialClient
from .hospital import HospitalClient

__all__ = [
    "WasteClient",
    "HouseholdClient",
    "IndustrialClient",
    "HospitalClient",
]
