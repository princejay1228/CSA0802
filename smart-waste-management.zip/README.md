# Smart Waste Management System

A modular, object-oriented Python system designed for urban municipal waste operations, collection scheduling, dynamic CSV-based billing, biomedical hospital compliance auditing, and reporting.

Developed for a **College Python Programming Lab Assignment**, this project strictly utilizes the **Python Standard Library** with zero third-party dependencies.

---

## Table of Contents

1. [Project Overview](#project-overview)
2. [Folder Structure](#folder-structure)
3. [Sub-Task Implementation Mapping](#sub-task-implementation-mapping)
4. [How to Run the Application](#how-to-run-the-application)
5. [Running Unit & Integration Tests](#running-unit--integration-tests)
6. [Interactive Menu & Workflow](#interactive-menu--workflow)
7. [Sample Outputs](#sample-outputs)
   - [CLI Interface](#cli-interface)
   - [Generated Receipt (`receipts/M001_receipt.txt`)](#generated-receipt)
   - [Dynamic Summary Report (`reports/summary_report.txt`)](#dynamic-summary-report)
   - [System Log (`logs/system.log`)](#system-log)
8. [Core OOP & Programming Concepts Demonstrated](#core-oop--programming-concepts-demonstrated)
9. [Requirements & Compatibility](#requirements--compatibility)

---

## Project Overview

Modern urban waste management involves diverse client sectors—households, industrial facilities, and hospitals—each with distinct collection schedules, handling protocols, disposal regulations, and billing models:
- **Households** generate general, recyclable, or organic waste with optional green rebates for segregation.
- **Industrial Facilities** generate manufacturing or hazardous/toxic materials that require environmental permits and containment surcharges.
- **Hospitals & Clinics** generate biomedical waste categorized by color codes (Yellow, Red, White, Blue) that require autoclave sterilization, high-temperature incineration, and strict regulatory compliance tracking.

This project delivers an end-to-end automated management system with persistent JSON records, CSV billing tables, receipt generation, event logging, and dynamic analytical reporting.

---

## Folder Structure

```text
SmartWasteManagement/
│
├── main.py                     # Primary interactive CLI application & event controller
│
├── models/                     # Object-Oriented Domain Models
│   ├── __init__.py             # Models package initialization
│   ├── waste_client.py         # Abstract Base Class: WasteClient
│   ├── household.py            # Derived Class: HouseholdClient
│   ├── industrial.py           # Derived Class: IndustrialClient
│   └── hospital.py             # Derived Class: HospitalClient (Biomedical compliance)
│
├── managers/                   # Persistence & Business Lifecycle Managers
│   ├── __init__.py             # Managers package initialization
│   ├── client_manager.py       # Client registry & JSON persistence
│   └── schedule_manager.py     # Collection schedule manager (schedules.json)
│
├── services/                   # Business Services
│   ├── __init__.py             # Services package initialization
│   ├── billing.py              # CSV rate loading, calculation & receipt generator
│   └── report_generator.py     # Aggregated dynamic summary report generator
│
├── data/                       # External Persistent Data Files
│   ├── clients.json            # Persisted client records
│   ├── schedules.json          # Persisted pickup schedules
│   └── rates.csv               # External billing rate tables by client & waste type
│
├── receipts/                   # Output directory for generated payment receipts (.txt)
│   ├── H001_receipt.txt
│   ├── I001_receipt.txt
│   └── M001_receipt.txt
│
├── reports/                    # Output directory for analytical reports (.txt)
│   └── summary_report.txt
│
├── logs/                       # System audit and event logging (.log)
│   └── system.log
│
├── tests/                      # Automated Unit and Integration Test Suite
│   ├── __init__.py
│   └── test_system.py          # Comprehensive test cases using unittest
│
├── README.md                   # Complete documentation and lab report guide
└── requirements.txt            # Environment specifications (Standard library only)
```

---

## Sub-Task Implementation Mapping

| Sub-Task | Assignment Requirement | Implementation in Codebase |
| :--- | :--- | :--- |
| **(a)** | **Base Class `WasteClient` & Derived Classes** | `models/waste_client.py` defines `WasteClient` (client ID, name, address, waste type, quantity, `get_details()`, `calculate_bill()`, `schedule_collection()`, `to_dict()`). Subclasses `HouseholdClient`, `IndustrialClient`, and `HospitalClient` override `calculate_bill()` and `get_details()` with domain-specific properties (biomedical categories, compliance statuses, permits). |
| **(b)** | **Schedule Manager using JSON** | `managers/schedule_manager.py` reads and writes `data/schedules.json`. Supports adding, viewing, updating, completing, and deleting schedules without hardcoded data. |
| **(c)** | **Load Rate Tables from CSV** | `services/billing.py` parses `data/rates.csv` using Python's standard `csv.DictReader`. Computes bills dynamically (`quantity * rate_per_kg` + subclass adjustments) with graceful missing-rate fallbacks. |
| **(d)** | **Receipt Generation in Text Files** | `services/billing.py` formats and saves receipts as `.txt` files in `receipts/` (e.g. `receipts/M001_receipt.txt`) with client details, rates, dates, and compliance metadata. |
| **(e)** | **System Event Logging** | Built-in `logging` module is configured in `main.py` to write to `logs/system.log`. Logs registrations, schedule modifications, bill calculations, receipts, compliance audits, and errors using `INFO`, `WARNING`, and `ERROR` levels. |
| **(f)** | **Dynamic Summary Reports** | `services/report_generator.py` calculates live statistics from `ClientManager`, `ScheduleManager`, and `BillingService` and outputs to `reports/summary_report.txt`. |

---

## How to Run the Application

### 1. Prerequisites
- Python **3.8 or newer** (compatible with Python 3.8, 3.9, 3.10, 3.11, 3.12, 3.13).
- No external packages (`pip install`) needed.

### 2. Launch the CLI
Open a terminal in the project root directory and run:

```bash
python3 main.py
```
*(Or `python main.py` on Windows)*

---

## Running Unit & Integration Tests

The project includes an automated test suite verifying all models, CSV parsing, JSON serialization, receipt generation, and report generation:

```bash
python3 -m unittest discover -s tests -p "test_*.py"
```

Expected Output:
```text
.......
----------------------------------------------------------------------
Ran 7 tests in 0.017s

OK
```

---

## Interactive Menu & Workflow

```text
==================================================
 Welcome to Smart Waste Management System v1.0
 Urban Municipal Operations & Compliance Control
==================================================

================================================
       SMART WASTE MANAGEMENT SYSTEM
================================================
 1. Register Client
 2. View Clients
 3. Add Collection Schedule
 4. View Collection Schedules
 5. Update Collection Schedule
 6. Calculate Bill
 7. Generate Receipt
 8. Complete Collection
 9. Check Hospital Compliance
 10. Generate Summary Report
 11. Exit
================================================
Enter your choice (1-11):
```

### Typical Workflow:
1. **Register a Client** (Option 1): Choose Household, Industrial, or Hospital. Enter ID, name, waste type, and quantity. Stored in `data/clients.json`.
2. **Schedule Pickup** (Option 3): Assign a date, time, and frequency to the client. Stored in `data/schedules.json`.
3. **Calculate Bill & Issue Receipt** (Option 6 & 7): Reads rates from `data/rates.csv` and outputs receipt to `receipts/{client_id}_receipt.txt`.
4. **Complete Collection** (Option 8): Updates schedule status to `Completed` and logs the event in `logs/system.log`.
5. **Hospital Compliance Audit** (Option 9): Review biomedical waste categories and update verification statuses (`Compliant`, `Pending Verification`, `Non-Compliant`).
6. **Generate Summary Report** (Option 10): Creates live analytical manifest in `reports/summary_report.txt`.

---

## Sample Outputs

### Generated Receipt (`receipts/M001_receipt.txt`)

```text
==================================================
       SMART WASTE MANAGEMENT SYSTEM
          OFFICIAL PAYMENT RECEIPT
==================================================
Receipt Date     : 2026-08-25 07:24:00
Client ID        : M001
Client Name      : City General Hospital
Client Type      : Hospital
Service Address  : 500 Healthcare Blvd, Metro Central
--------------------------------------------------
COLLECTION DETAILS
Collection Date  : 2026-08-27
Collection Time  : 05:30
Waste Type       : Biomedical
Waste Quantity   : 120.00 kg
Rate per kg      : $40.00 / kg
Base Charge      : $4800.00
Biohazard Sterilization Fee    : +$35.00
Biomedical Category            : Yellow (Anatomical & Chemotherapy)
Compliance Status              : Compliant
Disposal Requirements          : High-Temperature Incineration (1100°C)
Biohazard License #            : MED-BIO-9021
--------------------------------------------------
TOTAL AMOUNT DUE : $4835.00
==================================================
  Thank you for keeping our city clean and green!
  For support or compliance inquiries: support@smartwaste.city
==================================================
```

### Dynamic Summary Report (`reports/summary_report.txt`)

```text
==================================================================
             SMART WASTE MANAGEMENT SYSTEM - SUMMARY REPORT
==================================================================
Generated On           : 2026-08-25 07:24:00
Active Reporting Node  : Municipal Waste Operations Control Center
------------------------------------------------------------------
1. CLIENT DEMOGRAPHICS & REGISTRATION
   Total Registered Clients    : 6
   - Household Clients         : 2
   - Industrial Clients        : 2
   - Hospital/Medical Clients  : 2

2. WASTE VOLUME & FINANCIAL SUMMARY
   Total Waste Volume Tracked  : 769.00 kg
   Total Projected/Billed Rev  : $25381.35

3. COLLECTION OPERATIONS & SCHEDULE PERFORMANCE
   Total Schedules Logged      : 6
   - Completed Pickups         : 1
   - Pending/Scheduled Pickups : 5
   - Cancelled Pickups         : 0

4. BIOMEDICAL WASTE COMPLIANCE TRACKING (HOSPITALS)
   Total Hospitals Registered  : 2
   - Compliant Facilities      : 1
   - Pending Verification      : 1
   - Non-Compliant Facilities  : 0

   [!] ACTION REQUIRED FOR REGULATORY AUDITING:
       * PENDING VERIFY: ID=M002, Name=St. Jude Medical Clinic, Category=White (Puncture-Proof Sharps/Needles), Requirements=Autoclave Shredding & Encapsulation

5. SCHEDULE MANIFEST LISTING
   ------------------------------------------------------------
   Schedule ID  Client ID  Date         Time     Status      
   ------------------------------------------------------------
   SCH-001      H001       2026-08-28   08:00    Scheduled   
   SCH-002      H002       2026-08-29   09:30    Scheduled   
   SCH-003      I001       2026-08-26   06:00    Completed   
   SCH-004      I002       2026-08-30   07:00    Scheduled   
   SCH-005      M001       2026-08-27   05:30    Scheduled   
   SCH-006      M002       2026-08-28   11:00    In-Progress 
   ------------------------------------------------------------
==================================================================
                   END OF SUMMARY REPORT
==================================================================
```

### System Log (`logs/system.log`)

```text
2026-08-25 07:23:59,102 [INFO] [main.py:44] - Smart Waste Management System session initialized.
2026-08-25 07:24:00,210 [INFO] [client_manager.py:84] - Client registered: ID=H001, Name=John & Mary Smith, Type=Household
2026-08-25 07:24:01,004 [INFO] [schedule_manager.py:102] - Schedule created: ID=SCH-001 for Client=H001 on 2026-08-28 at 08:00
2026-08-25 07:24:02,118 [INFO] [billing.py:126] - Bill calculated for Client M001 (City General Hospital): Qty=120.0kg, Type=Biomedical, Total=$4835.00
2026-08-25 07:24:02,120 [INFO] [billing.py:196] - Receipt generated successfully: receipts/M001_receipt.txt (Client: M001)
2026-08-25 07:24:03,450 [INFO] [report_generator.py:148] - Summary report generated successfully at: reports/summary_report.txt
```

---

## Core OOP & Programming Concepts Demonstrated

1. **Object-Oriented Programming (OOP)**:
   - **Encapsulation**: Private and protected attributes (`_client_id`, `_name`, `_waste_quantity`) with getters, setters, and validation.
   - **Inheritance**: Subclasses (`HouseholdClient`, `IndustrialClient`, `HospitalClient`) derive from the abstract base class `WasteClient`.
   - **Polymorphism & Method Overriding**: Subclasses override `calculate_bill()` and `get_details()` to introduce sector-specific rules (green rebates, hazardous containment fees, sterilization surcharges).

2. **File Handling & External Data Persistence**:
   - **JSON Serialization (`json` module)**: `ClientManager` and `ScheduleManager` deserialize JSON into live polymorphic objects and persist state on update.
   - **CSV Processing (`csv` module)**: Dynamic parsing of rate tables with error handling and fallback support.
   - **Text File Generation**: Clean formatting and export of receipts and operational summary reports.

3. **System Logging (`logging` module)**:
   - Persistent logging to `logs/system.log` with timestamped levels (`INFO`, `WARNING`, `ERROR`).

4. **Modular Architecture & Clean Code**:
   - Distinct separation of concerns across `models`, `managers`, `services`, `data`, and `tests`.
   - Robust input validation to prevent crashes from bad user entries.

---

## Requirements & Compatibility

- **Python Version**: Python 3.8, 3.9, 3.10, 3.11, 3.12, or 3.13.
- **Dependencies**: Python Standard Library only (`json`, `csv`, `logging`, `os`, `sys`, `datetime`, `unittest`, `abc`). No `pip` installations needed.
