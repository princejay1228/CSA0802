"""
Managers package for Smart Waste Management System.
"""
from .schedule_manager import ScheduleManager
from .client_manager import ClientManager

__all__ = ["ScheduleManager", "ClientManager"]
