"""
Client Manager module for managing and persisting WasteClient instances using JSON files.
"""
import os
import json
import logging
from typing import List, Dict, Any, Optional
from models.waste_client import WasteClient
from models.household import HouseholdClient
from models.industrial import IndustrialClient
from models.hospital import HospitalClient

logger = logging.getLogger("SmartWasteManager")


class ClientManager:
    """
    Handles client registry, persistence in clients.json, and polymorphism.
    """

    def __init__(self, file_path: str = "data/clients.json") -> None:
        self.file_path = file_path
        self._ensure_file_exists()

    def _ensure_file_exists(self) -> None:
        try:
            directory = os.path.dirname(self.file_path)
            if directory and not os.path.exists(directory):
                os.makedirs(directory, exist_ok=True)
            if not os.path.exists(self.file_path):
                with open(self.file_path, "w", encoding="utf-8") as f:
                    json.dump([], f, indent=4)
                logger.info(f"Initialized empty clients file at: {self.file_path}")
        except Exception as e:
            logger.error(f"Error creating client file {self.file_path}: {e}")

    def load_clients(self) -> List[WasteClient]:
        """
        Loads and reconstructs polymorphic WasteClient objects from JSON file.
        """
        try:
            if not os.path.exists(self.file_path):
                self._ensure_file_exists()
                return []
            with open(self.file_path, "r", encoding="utf-8") as f:
                data_list = json.load(f)
                if not isinstance(data_list, list):
                    logger.warning("clients.json is not a valid list.")
                    return []
                
                clients: List[WasteClient] = []
                for item in data_list:
                    client_type = item.get("client_type", "").lower()
                    if client_type == "household":
                        clients.append(HouseholdClient.from_dict(item))
                    elif client_type == "industrial":
                        clients.append(IndustrialClient.from_dict(item))
                    elif client_type == "hospital":
                        clients.append(HospitalClient.from_dict(item))
                    else:
                        logger.warning(f"Unknown client type '{client_type}' for ID {item.get('client_id')}")
                return clients
        except json.JSONDecodeError as jde:
            logger.error(f"Failed to parse clients.json: {jde}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error loading clients: {e}")
            return []

    def save_clients(self, clients: List[WasteClient]) -> bool:
        """
        Saves all client objects to the JSON file.
        """
        try:
            directory = os.path.dirname(self.file_path)
            if directory and not os.path.exists(directory):
                os.makedirs(directory, exist_ok=True)
            serialized = [c.to_dict() for c in clients]
            with open(self.file_path, "w", encoding="utf-8") as f:
                json.dump(serialized, f, indent=4)
            return True
        except Exception as e:
            logger.error(f"Failed to save clients to {self.file_path}: {e}")
            return False

    def register_client(self, client: WasteClient) -> bool:
        """
        Registers a new client if ID does not already exist.
        """
        clients = self.load_clients()
        for existing in clients:
            if existing.client_id.upper() == client.client_id.upper():
                logger.warning(f"Registration failed: Client ID '{client.client_id}' already exists.")
                return False
        
        clients.append(client)
        if self.save_clients(clients):
            logger.info(f"Client registered: ID={client.client_id}, Name={client.name}, Type={client.client_type}")
            return True
        return False

    def find_client(self, client_id: str) -> Optional[WasteClient]:
        """
        Searches for a client by ID.
        """
        clients = self.load_clients()
        for client in clients:
            if client.client_id.upper() == client_id.strip().upper():
                return client
        return None

    def get_all_clients(self) -> List[WasteClient]:
        """
        Returns all registered clients.
        """
        return self.load_clients()

    def update_hospital_compliance(self, client_id: str, new_status: str) -> bool:
        """
        Updates compliance status for a hospital client.
        """
        clients = self.load_clients()
        updated = False
        for client in clients:
            if client.client_id.upper() == client_id.strip().upper():
                if isinstance(client, HospitalClient):
                    if client.update_compliance_status(new_status):
                        updated = True
                        logger.info(
                            f"Hospital compliance updated: Client={client_id} ({client.name}) -> Status={new_status}"
                        )
                        break
                    else:
                        logger.warning(f"Invalid compliance status '{new_status}' provided for {client_id}")
                        return False
                else:
                    logger.warning(f"Client '{client_id}' is not a HospitalClient.")
                    return False

        if updated:
            return self.save_clients(clients)
        return False
