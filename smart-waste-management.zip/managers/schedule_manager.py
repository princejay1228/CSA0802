"""
Schedule Manager module for handling waste collection schedules using external JSON files.
Demonstrates file handling, JSON serialization/deserialization, and exception management.
"""
import os
import json
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime

logger = logging.getLogger("SmartWasteManager")


class ScheduleManager:
    """
    Manages collection schedules stored in an external JSON file.
    """

    def __init__(self, file_path: str = "data/schedules.json") -> None:
        self.file_path = file_path
        self._ensure_file_exists()

    def _ensure_file_exists(self) -> None:
        """
        Creates directory and initializes JSON file if it does not exist.
        """
        try:
            directory = os.path.dirname(self.file_path)
            if directory and not os.path.exists(directory):
                os.makedirs(directory, exist_ok=True)
            if not os.path.exists(self.file_path):
                with open(self.file_path, "w", encoding="utf-8") as f:
                    json.dump([], f, indent=4)
                logger.info(f"Initialized empty schedules file at: {self.file_path}")
        except Exception as e:
            logger.error(f"Failed to initialize schedule file {self.file_path}: {e}")

    def load_schedules(self) -> List[Dict[str, Any]]:
        """
        Loads all schedules from the JSON file.
        """
        try:
            if not os.path.exists(self.file_path):
                self._ensure_file_exists()
                return []
            with open(self.file_path, "r", encoding="utf-8") as f:
                schedules = json.load(f)
                if not isinstance(schedules, list):
                    logger.warning("Invalid format in schedules.json; expected a JSON list.")
                    return []
                return schedules
        except json.JSONDecodeError as jde:
            logger.error(f"Corrupted JSON in schedules file {self.file_path}: {jde}")
            return []
        except Exception as e:
            logger.error(f"Error reading schedules from {self.file_path}: {e}")
            return []

    def save_schedules(self, schedules: List[Dict[str, Any]]) -> bool:
        """
        Persists schedule records to the JSON file.
        """
        try:
            directory = os.path.dirname(self.file_path)
            if directory and not os.path.exists(directory):
                os.makedirs(directory, exist_ok=True)
            with open(self.file_path, "w", encoding="utf-8") as f:
                json.dump(schedules, f, indent=4)
            return True
        except Exception as e:
            logger.error(f"Failed to save schedules to {self.file_path}: {e}")
            return False

    def add_schedule(
        self,
        client_id: str,
        collection_date: str,
        collection_time: str,
        frequency: str = "Weekly",
        status: str = "Scheduled"
    ) -> Optional[Dict[str, Any]]:
        """
        Creates and stores a new collection schedule.
        """
        schedules = self.load_schedules()
        
        # Generate next schedule ID (e.g. SCH-001)
        schedule_count = len(schedules) + 1
        schedule_id = f"SCH-{schedule_count:03d}"
        
        # Avoid ID collisions if schedules were deleted
        existing_ids = {s.get("schedule_id") for s in schedules}
        while schedule_id in existing_ids:
            schedule_count += 1
            schedule_id = f"SCH-{schedule_count:03d}"

        new_schedule = {
            "schedule_id": schedule_id,
            "client_id": client_id,
            "collection_date": collection_date,
            "collection_time": collection_time,
            "frequency": frequency,
            "status": status,
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

        schedules.append(new_schedule)
        if self.save_schedules(schedules):
            logger.info(
                f"Schedule created: ID={schedule_id} for Client={client_id} on {collection_date} at {collection_time}"
            )
            return new_schedule
        else:
            logger.error(f"Could not persist schedule {schedule_id}")
            return None

    def get_all_schedules(self) -> List[Dict[str, Any]]:
        """
        Returns all collection schedules.
        """
        return self.load_schedules()

    def find_schedule_by_id(self, schedule_id: str) -> Optional[Dict[str, Any]]:
        """
        Finds a specific schedule by its schedule_id.
        """
        schedules = self.load_schedules()
        for sch in schedules:
            if sch.get("schedule_id", "").upper() == schedule_id.strip().upper():
                return sch
        return None

    def find_schedules_by_client(self, client_id: str) -> List[Dict[str, Any]]:
        """
        Returns all collection schedules associated with a given client ID.
        """
        schedules = self.load_schedules()
        return [
            s for s in schedules
            if s.get("client_id", "").upper() == client_id.strip().upper()
        ]

    def update_schedule(
        self,
        schedule_id: str,
        collection_date: Optional[str] = None,
        collection_time: Optional[str] = None,
        frequency: Optional[str] = None,
        status: Optional[str] = None
    ) -> bool:
        """
        Updates fields of an existing collection schedule.
        """
        schedules = self.load_schedules()
        updated = False

        for sch in schedules:
            if sch.get("schedule_id", "").upper() == schedule_id.strip().upper():
                if collection_date:
                    sch["collection_date"] = collection_date.strip()
                if collection_time:
                    sch["collection_time"] = collection_time.strip()
                if frequency:
                    sch["frequency"] = frequency.strip()
                if status:
                    sch["status"] = status.strip()
                sch["updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                updated = True
                break

        if updated and self.save_schedules(schedules):
            logger.info(f"Schedule updated: ID={schedule_id} (Status={status or 'Unchanged'})")
            return True
        elif not updated:
            logger.warning(f"Schedule update failed: Schedule ID '{schedule_id}' not found.")
            return False
        else:
            logger.error(f"Failed to persist update for schedule ID '{schedule_id}'")
            return False

    def delete_schedule(self, schedule_id: str) -> bool:
        """
        Removes a schedule by ID.
        """
        schedules = self.load_schedules()
        initial_len = len(schedules)
        schedules = [
            s for s in schedules
            if s.get("schedule_id", "").upper() != schedule_id.strip().upper()
        ]

        if len(schedules) < initial_len:
            if self.save_schedules(schedules):
                logger.info(f"Schedule deleted: ID={schedule_id}")
                return True
            else:
                logger.error(f"Failed to save schedules after deleting {schedule_id}")
                return False
        else:
            logger.warning(f"Schedule deletion failed: ID '{schedule_id}' not found.")
            return False

    def complete_collection(self, schedule_id: str) -> bool:
        """
        Marks a collection schedule as 'Completed'.
        """
        return self.update_schedule(schedule_id=schedule_id, status="Completed")
